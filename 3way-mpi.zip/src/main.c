#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <mpi.h>
#define MASTER 0

int find_max(char* line, int nchars){
    int i;
    //int j;
    int max = 0;
    
    for ( i = 0; i < nchars; i++ ) {
        if (((int) line[i]) > max){
            max = ((int) line[i]);
        }
        //sum += ((int) line[i]);
    }
    
    if (nchars > 0){
        return max;
    } else {
        return 0;
    }
}


/*
int main(int argc, char *argv[])
{ 
  int numtasks, taskid, len; 
  char hostname[MPI_MAX_PROCESSOR_NAME];
  
  MPI_Status status;
  
  bool inBool = false;
  bool outBool = true;

   int nlines = 0, maxlines = 1000;
   int threads = 20;
   int i,k, err;
   //float  charsum=0.0;
   int max;
   FILE *fd;
   

// Read in the lines from the data file


   fd = fopen( "/homes/dan/625/wiki_dump.txt", "r" );
   MPI_Init(&argc, &argv); 
	MPI_Comm_size(MPI_COMM_WORLD, &numtasks);
	MPI_Comm_rank(MPI_COMM_WORLD,&taskid); 
	MPI_Get_processor_name(hostname, &len);
	
	threads = numtasks;
	
	char *line[threads]; // no lines larger than 2000 chars
	
   for (k = 0; k < maxlines; k = k + threads){
        inBool = false;
		  
	   for ( i = 0; i < threads; i++ )  {
		  line[i] = (char*) malloc( 2001 ); 
		  err = fscanf( fd, "%[^\n]\n", line[i]);
		  if( err == EOF ) break;
		  nlines++;
	   }
		MPI_Barrier (MPI_COMM_WORLD);
		max = find_max(line[taskid], strlen(line[taskid]));
		if (taskid == MASTER){
		    if (k) {
		        MPI_Recv(&inBool, 1,MPI_C_BOOL, threads - 1, k + taskid-1, MPI_COMM_WORLD, &status);
		    }
			printf("%d: %d\n", k + taskid, max);
			MPI_Send(&outBool, 1, MPI_C_BOOL, taskid + 1, k + taskid, MPI_COMM_WORLD);
		}else if ( taskid == threads - 1){
			MPI_Recv(&inBool, 1,MPI_C_BOOL, taskid - 1, k + taskid-1, MPI_COMM_WORLD, &status);
			printf("%d: %d\n", k + taskid, max);
			MPI_Send(&outBool, 1, MPI_C_BOOL, MASTER, k + taskid, MPI_COMM_WORLD);
		} else 	{
			MPI_Recv(&inBool, 1,MPI_C_BOOL, taskid - 1, k + taskid-1, MPI_COMM_WORLD, &status);
			printf("%d: %d\n", k + taskid, max);
			MPI_Send(&outBool, 1, MPI_C_BOOL, taskid + 1, k + taskid, MPI_COMM_WORLD);
		}			
		MPI_Barrier (MPI_COMM_WORLD);
		for (i = 0; i < threads; i ++){
		    free(line[i]);
		}
		
   }
	MPI_Finalize();
	fclose( fd );
}

*/



int main(int argc, char *argv[])
{ 


  int numtasks, taskid, len; 
  char hostname[MPI_MAX_PROCESSOR_NAME];
  
  //MPI_Status status;
  

   int nlines = 0, maxlines = 100000;
   int threads = 20;
   int i,k, err;
   //float  charsum=0.0;
   int max;
   FILE *fd;
   
 
   

// Read in the lines from the data file


   fd = fopen( "/homes/dan/625/wiki_dump.txt", "r" );
   MPI_Init(&argc, &argv); 
	MPI_Comm_size(MPI_COMM_WORLD, &numtasks);
	MPI_Comm_rank(MPI_COMM_WORLD,&taskid); 
	MPI_Get_processor_name(hostname, &len);
	
	threads = numtasks;
	
	char *line[threads]; // no lines larger than 2000 chars
	//int recBuf[threads];
	
	int* recBuf = NULL;
	if (taskid == MASTER){
	    recBuf = (int*) malloc(sizeof(int) * threads);
	    }
	
   for (k = 0; k < maxlines; k = k + threads){
        //inBool = false;
		  
	   for ( i = 0; i < threads; i++ )  {
		  line[i] = (char*) malloc( 2001 ); 
		  err = fscanf( fd, "%[^\n]\n", line[i]);
		  if( err == EOF ) break;
		  nlines++;
	   }
	   
	   max = find_max(line[taskid], strlen(line[taskid]));
	   
		//MPI_Barrier (MPI_COMM_WORLD);
		MPI_Gather (&max, 1, MPI_INT, recBuf, 1, MPI_INT, 0, MPI_COMM_WORLD);
		if (taskid == 0){
		    for(i = 0; i < threads; i++){
		        printf ("%d: %d\n", k+i, recBuf[i]);
		    }
		}
		        
		        
		for (i = 0; i < threads; i ++){
		    free(line[i]);
		}
		
   }
	MPI_Finalize();
	fclose( fd );
	
}

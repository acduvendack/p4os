#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define NUM_THREADS 40

int nlines = 0, maxlines = 1000000;
int i, err;
//float  charsum=0.0;
int nchars = 0;
char *line = (char*) malloc( 2001 ); // no lines larger than 2000 chars

void *myThread(void *vargp)
{
    for ( i = 0; i < maxlines; i++ )  {
      err = fscanf( fd, "%[^\n]\n", line);
      if( err == EOF ) break;
      nchars = strlen( line );
      printf("%d: %d\n", nlines, find_max(line, nchars));
      nlines++;
   }
}

int find_max(char* line, int nchars){
    int i;
    //int j;
    int max = 0;
    
    for ( i = 0; i < nchars; i++ ) {
        if (((int) line[i]) > max){
            max = ((int) line[i]);
        }
        //sum += ((int) line[i]);
    }
    
    if (nchars > 0){
        return max;
    } else {
        return 0;
    }
}

int main()
{
   FILE *fd;
   pthread_t threads[NUM_THREADS];
   long t;
   int rc;

// Read in the lines from the data file

   fd = fopen( "/homes/dan/625/wiki_dump.txt", "r" );
   
   for(t=0; t<NUM_THREADS; t++){
       rc = pthread_create(&threads[t], NULL, myThread, (void *)t);
       if (rc){
          printf("ERROR; return code from pthread_create() is %d\n", rc);
          exit(-1);
       }
    }
    
    pthread_exit(NULL);

   fclose( fd );

}
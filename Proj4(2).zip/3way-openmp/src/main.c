#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>

int find_max(char* line, int nchars){
    int max = 0;
    int i;

    for ( i = 0; i < nchars; i++ ) {
        if (((int) line[i]) > max){
            max = ((int) line[i]);
        }
    }
    
    if (nchars > 0){
        return max;
    } else {
        return 0;
    }
}

int main()
{
   int maxlines = 1000000;
   int threads = 20;
   int i = 0;
   FILE *fd;
   int err[threads];
   char *line[threads];
   int nchars;
   int j = 0;
   int k = 0;
   
   int maxes[threads];
   fd = fopen( "/homes/dan/625/wiki_dump.txt", "r" );
   
   for(k = 0; k < maxlines; k=k+threads){
       #pragma omp parallel for num_threads(20)
            for (i = 0; i < threads; i++){
                maxes[i] = 0;
            }
       
       for (i = 0; i < threads; i++){
            line[i] = (char*) calloc( 2001, sizeof(char) );
            err[i] = fscanf( fd, "%[^\n]\n", line[i]);
            if (err[i] == EOF){
                break;
            }
       }
       
        #pragma omp parallel private(err, nchars) num_threads(20)
        {
            nchars = 0;
        
            #pragma omp for
                for ( i = 0; i < threads; i++ )  {
                    
                    nchars = strlen( line[i] );
                    maxes[i] = find_max(line[i], nchars);
                    
                    
                }
        }
    
        for(i = 0; i < threads; i++){
            printf("%d: %d\n", j, maxes[i]);
            free(line[i]);
            j++;
        }
    }

   fclose( fd );

}
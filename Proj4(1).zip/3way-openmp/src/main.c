#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>

int find_max(char* line, int nchars){
    int i;
    //int j;
    int max = 0;
    
    for ( i = 0; i < nchars; i++ ) {
        if (((int) line[i]) > max){
            max = ((int) line[i]);
        }
        //sum += ((int) line[i]);
    }
    
    if (nchars > 0){
        return max;
    } else {
        return 0;
    }
}

int main()
{
   int nlines = 0, maxlines = 1000000;
   int i = 0, err;
   //float  charsum=0.0;
   int nchars = 0;
   FILE *fd;
   char *line = (char*) malloc( 2001 ); // no lines larger than 2000 chars

// Read in the lines from the data file

   fd = fopen( "/homes/dan/625/wiki_dump.txt", "r" );
   
   #pragma omp parallel
   {
        while ( i < maxlines)  {
            err = fscanf( fd, "%[^\n]\n", line);
            if( err != EOF ) {
                nchars = strlen( line );
                printf("%d: %d\n", nlines, find_max(line, nchars));
                nlines++;
                i++;
            }
        }
        
/*Parallel section executed by all threads 
                 .
Other OpenMP directives
                 .
Run-time Library calls
                 .
All threads join master thread and disband*/
    }
   
   /*for ( i = 0; i < maxlines; i++ )  {
      err = fscanf( fd, "%[^\n]\n", line);
      if( err == EOF ) break;
      nchars = strlen( line );
      printf("%d: %d\n", nlines, find_max(line, nchars));
      nlines++;
   }*/

   fclose( fd );

}
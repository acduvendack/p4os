#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <mpi.h>
#define MASTER 0


// finds the max ASCII on a line
int find_max(char* line, int nchars){
    int i;
   
    int max = 0;
    
    //finds max
    for ( i = 0; i < nchars; i++ ) {
        if (((int) line[i]) > max){
            max = ((int) line[i]);
        }
    }
    
    if (nchars > 0){
        return max;
    } else {
        return 0;
    }
}




int main(int argc, char *argv[])
{ 


  int numtasks, taskid, len; 
  char hostname[MPI_MAX_PROCESSOR_NAME];
  
  //MPI_Status status;
  

   int nlines = 0, maxlines = 100000;
   int threads = 20;
   int i,k, err;
   //float  charsum=0.0;
   int max;
   FILE *fd;
   
 
   

// Read in the lines from the data file

    //initialize file and mpi
   fd = fopen( "/homes/dan/625/wiki_dump.txt", "r" );
   MPI_Init(&argc, &argv); 
	MPI_Comm_size(MPI_COMM_WORLD, &numtasks);
	MPI_Comm_rank(MPI_COMM_WORLD,&taskid); 
	MPI_Get_processor_name(hostname, &len);
	
	//sets number of threads
	threads = numtasks;
	
	
	//buffer to hold read in data
	char *line[threads]; // no lines larger than 2000 chars
	
	//initialize receiving buffer
	int* recBuf = NULL;
	if (taskid == MASTER){
	    recBuf = (int*) malloc(sizeof(int) * threads);
	    }
	
	//main loop
   for (k = 0; k < maxlines; k = k + threads){
		  
		  //reads in data to the array, the array is the size of the number of threads
	   for ( i = 0; i < threads; i++ )  {
		  line[i] = (char*) malloc( 2001 ); 
		  err = fscanf( fd, "%[^\n]\n", line[i]);
		  if( err == EOF ) break;
		  nlines++;
	   }
	   
	   //finds the max value of a line based on the tasks id
	   max = find_max(line[taskid], strlen(line[taskid]));
	   
		//Gathers all of the max chars that each process found
		MPI_Gather (&max, 1, MPI_INT, recBuf, 1, MPI_INT, 0, MPI_COMM_WORLD);
		
		//root process then prints the chars in order of lines
		if (taskid == 0){
		    for(i = 0; i < threads; i++){
		        printf ("%d: %d\n", k+i, recBuf[i]);
		    }
		}
		        
		
		//free malloc and calloc vars        
		for (i = 0; i < threads; i ++){
		    free(line[i]);
		}
		if (taskid == MASTER){
		    free (recBuf);
		}
		
   }
	MPI_Finalize();
	fclose( fd );
	
}
